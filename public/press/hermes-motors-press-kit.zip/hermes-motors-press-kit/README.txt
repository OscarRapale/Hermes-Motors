HERMES MOTORS · PRESS KIT · DAY ONE EDITION

Hermes Motors is a fictional team, made as a portfolio project. Not affiliated with Formula 1, the FIA, Porsche or Hermès.

Credit for car images (run it with every render or film frame you publish):
3D model based on “2026 F1 CAR” by Abu Saif, CC BY 4.0, modified.

renders/  the HM-27, PNG, 2400 × 1500
brand/    the mark, the wordmark and the lock-up, SVG and PNG. Keep the 14° lean and clear space of one feather around the mark. Never recolour the feathers.
film/     First Light, MP4 1080p, 24 s, silent, and its poster frame
